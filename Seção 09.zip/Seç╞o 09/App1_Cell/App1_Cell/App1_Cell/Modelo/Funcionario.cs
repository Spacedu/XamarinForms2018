﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App1_Cell.Modelo
{
    public class Funcionario
    {
        public string Nome { get; set; }
        public string Cargo { get; set; }
        public string Foto { get; set; }

    }
}
