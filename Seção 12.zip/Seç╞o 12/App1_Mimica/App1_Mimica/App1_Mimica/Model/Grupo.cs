﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App1_Mimica.Model
{
    public class Grupo
    {
        public string Nome { get; set; }
        public short Pontuacao { get; set; }
    }
}
