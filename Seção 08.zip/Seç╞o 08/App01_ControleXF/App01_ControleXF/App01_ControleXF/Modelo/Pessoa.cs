﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App01_ControleXF.Modelo
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public string Idade { get; set; }
    }
}
