﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App1_Vagas.Banco
{
    public interface ICaminho
    {
        string ObterCaminho(string NomeArquivoBanco);
    }
}
